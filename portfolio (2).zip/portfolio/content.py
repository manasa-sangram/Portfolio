"""
content.py  -  ALL the text of your website lives here.

The templates (HTML) decide HOW things look. This file decides WHAT they say.
To change a sentence, a link, a book or a photo caption, edit this file only.

Everything marked TODO is a placeholder for YOU to fill in. I only used facts
from your resume and from what you told me; I did not invent anything personal.

The sections appear on the site in the same order as the QUESTS list below.
"""

# ---------------------------------------------------------------------------
# Basic identity (sidebar, page title, footer)
# ---------------------------------------------------------------------------
SITE = {
    "name": "Manasa Sangram Ashok",
    "short_name": "Manasa",
    "tagline": "Data & ML engineer building reliable pipelines and learning from time-series data.",
    "location": "Rostock, Germany (open to relocation / remote)",
    # TODO: replace with your real profile links
    "linkedin": "https://www.linkedin.com/in/YOUR-HANDLE",
    "github": "https://github.com/YOUR-HANDLE",
    "substack": "https://YOUR-NAME.substack.com",
    "loom": "https://www.loom.com/share/YOUR-VIDEO-ID",
    # Put your resume PDF in the static/ folder with exactly this name.
    # The "Resume" buttons only appear once the file exists.
    "resume_file": "Manasa_Resume.pdf",
}

# The sidebar menu. (id, label). The id must match the id of the section in
# templates/sections/. Order here = order in the menu.
QUESTS = [
    {"id": "highlights", "label": "Highlights"},
    {"id": "work", "label": "Work & Projects"},
    {"id": "lookbook", "label": "Personal Lookbook"},
    {"id": "corner", "label": "My Corner"},
    {"id": "german", "label": "German Journey"},
    {"id": "videos", "label": "Videos"},
    {"id": "education", "label": "Education"},
    {"id": "offduty", "label": "When I'm not working"},
    {"id": "contact", "label": "Write to me"},
]

# ---------------------------------------------------------------------------
# 1. Highlights about me
# ---------------------------------------------------------------------------
HIGHLIGHTS = {
    "headline": "Hi, I'm Manasa.",
    # The "I love ..." line rotates through these
    "loves": [
        "building data pipelines",
        "finding anomalies in ocean data",
        "dancing",
        "reading",
        "hitting the gym",
        "running",
        "journalling",
    ],
    "welcome": "welcome to my little corner of the internet.",
    "intro": (
        "I'm a Master's student in Computer Science (AI focus) at the University of "
        "Rostock. I build high-throughput data pipelines, automated testing suites "
        "and now machine learning models that find anomalies in oceanographic sensor data."
    ),
    "looking_for": "Open to Data Engineer and Machine Learning Engineer roles (full time). Open to relocation and remote.",
    # The skills list under the intro: a group name and the skills in it
    "skills": [
        {"group": "Data & ML", "items": ["Python", "SQL", "Pandas", "Machine learning"]},
        {"group": "Pipelines & APIs", "items": ["FastAPI", "RabbitMQ", "Docker", "Streamlit"]},
        {"group": "Testing & delivery", "items": ["Playwright", "TypeScript", "Git", "CI/CD"]},
    ],
    # "At a glance": the key facts
    "stats": [
        {"label": "Role", "value": "Data & ML Engineer"},
        {"label": "Location", "value": "Rostock, Germany"},
        {"label": "Experience", "value": "2+ years"},
        {"label": "Languages", "value": "English C1 · German B1"},
        {"label": "Currently", "value": "Master's thesis at IOW"},
        {"label": "Looking for", "value": "Full-time Data / ML Engineer role"},
    ],
}

# ---------------------------------------------------------------------------
# 2. Work (tab 1) and Projects (tab 2)
# ---------------------------------------------------------------------------
WORK = [
    {
        "role": "Master's Thesis: Anomaly Detection in CTD Data using Machine Learning",
        "where": "Leibniz Institute for Baltic Sea Research Warnemünde (IOW), Rostock",
        "dates": "Sep 2026 - present",
        "current": True,  # shows "Current" next to the dates
        "bullets": [
            "Working through about 800 CTD data files, combined into one Pandas dataframe.",
            "Comparing unsupervised methods, self-supervised learning (TS2Vec embeddings) and a foundation model (Chronos-2) for automated data quality assessment.",
            "Goal: find errors in high-frequency oceanographic time series automatically.",
        ],
        # TODO: add links when you publish. Leave "" to hide the button.
        "links": [
            {"label": "Read the write-up (Substack)", "url": ""},
            {"label": "Watch the walkthrough (Loom)", "url": ""},
        ],
    },
    {
        "role": "Working Student, Data Engineering & Software Automation",
        "where": "Suzlon Energy, Rostock",
        "dates": "Mar 2025 - present",
        "bullets": [
            "Built a multi-threaded, object-oriented Python pipeline that processes 800 engineering entities in under 2 minutes.",
            "Used the Polarion API to generate about 800 files automatically; worked on API backend testing.",
            "Built a YAML-configured Streamlit dashboard so PLC engineers can add configurations and start the FLEX5 application.",
            "Documented pipelines and set up Git version control, code-quality standards and CI/CD across teams.",
        ],
    },
    {
        "role": "Software Engineer, Quality Assurance & Test Engineering",
        "where": "Oracle Corporation, Bengaluru",
        "dates": "Sep 2023 - Nov 2024",
        "bullets": [
            "Cut end-to-end regression time by 40% with automated test frameworks (TypeScript/JavaScript, Playwright).",
            "Debugged and isolated root causes of production pipeline bottlenecks in agile, cross-functional teams.",
            "Kept zero critical vulnerabilities across 4 enterprise releases by adding automated security scans to CI.",
        ],
    },
]

PROJECTS = [
    {
        "name": "Event-Driven Sensor Data Streaming Pipeline",
        "stack": ["Python", "FastAPI", "RabbitMQ", "Streamlit", "Docker"],
        "text": "Real-time ingestion of industrial sensor data. RabbitMQ queues process the streams asynchronously with sub-second latency.",
        "link": "",  # TODO: GitHub link
    },
    {
        "name": "AI Invoice & Data Extraction Agent",
        "stack": ["n8n", "Python", "REST APIs", "Google APIs"],
        "text": "Receipts arrive through Telegram, an LLM extracts the fields, and verified data is written to cloud tables.",
        "link": "",  # TODO: GitHub link
    },
]

# ---------------------------------------------------------------------------
# 3. Personal Lookbook: tab "Travel" and tab "New things I'm trying"
# "file" = a file name inside static/photos/. Until the file exists, a coloured
# placeholder is shown. Add or remove entries freely.
# ---------------------------------------------------------------------------
LOOKBOOK_TRAVEL = [
    {"file": "travel1.jpg", "caption": "TODO place"},
    {"file": "travel2.jpg", "caption": "TODO place"},
    {"file": "travel3.jpg", "caption": "TODO place"},
    {"file": "travel4.jpg", "caption": "TODO place"},
]
LOOKBOOK_NEW = [
    {"file": "new1.jpg", "caption": "TODO new thing"},
    {"file": "new2.jpg", "caption": "TODO new thing"},
    {"file": "new3.jpg", "caption": "TODO new thing"},
    {"file": "new4.jpg", "caption": "TODO new thing"},
]

# ---------------------------------------------------------------------------
# 4. My Corner: Substack, podcasts, books, what excites me, music, lessons
# "entries" is a list of short lines. "link" is optional.
# ---------------------------------------------------------------------------
CORNER = [
    {"file": "substack.md", "title": "Substack",
     "text": "My writing lives on Substack. TODO: one line about what you write about.",
     "link": SITE["substack"], "link_label": "Read on Substack"},
    {"file": "podcasts.txt", "title": "Podcasts I listen to",
     "entries": ["TODO: podcast 1", "TODO: podcast 2", "TODO: podcast 3"]},
    {"file": "books.txt", "title": "Books I read",
     "entries": ["TODO: book 1", "TODO: book 2", "TODO: book 3"]},
    {"file": "curious_about.txt", "title": "New things that excite me",
     "entries": ["Neuroplasticity", "Game engines"]},
    {"file": "music.txt", "title": "Music I listen to",
     "entries": ["TODO: artist or playlist 1", "TODO: artist or playlist 2", "TODO: artist or playlist 3"]},
    {"file": "lessons_2026.txt", "title": "Lessons I learnt this year",
     "entries": ["TODO: lesson 1", "TODO: lesson 2", "TODO: lesson 3"]},
]

# ---------------------------------------------------------------------------
# 5. My German language journey
# Your resume says German B1 (conversational), so A1 and A2 are marked done.
# "state" can be: done, current, next, later
# ---------------------------------------------------------------------------
GERMAN = {
    "intro": "TODO: tell the story. Why you started learning German, what was hardest, what helped.",
    "levels": [
        {"code": "A1", "name": "Beginner", "state": "done"},
        {"code": "A2", "name": "Elementary", "state": "done"},
        {"code": "B1", "name": "Intermediate", "state": "current"},
        {"code": "B2", "name": "Upper-intermediate", "state": "next"},
        {"code": "C1", "name": "Advanced", "state": "later"},
    ],
    "milestones": [
        {"when": "TODO: date", "text": "TODO: a milestone, e.g. first conversation, passed an exam"},
        {"when": "TODO: date", "text": "TODO: another milestone"},
        {"when": "TODO: date", "text": "TODO: another milestone"},
    ],
}

# ---------------------------------------------------------------------------
# 6. Videos. Leave "url" empty and the row shows "Coming soon".
# ---------------------------------------------------------------------------
VIDEOS = [
    {
        "title": "AI agents, explained",
        "text": "I learnt about AI agents and explained them in my own words.",
        "url": "",  # TODO: paste your Loom link here
    },
    {
        "title": "More Loom videos",
        "text": "New self-explaining videos will land here.",
        "url": "",
    },
]

# ---------------------------------------------------------------------------
# 7. Education: Cluny Convent -> SJCIT -> University of Rostock
# ---------------------------------------------------------------------------
EDUCATION = [
    {"school": "Cluny Convent", "what": "TODO: e.g. school", "years": "TODO: years"},
    {"school": "SJCIT", "what": "TODO: degree and field", "years": "TODO: years"},
    {"school": "University of Rostock", "what": "M.Sc. Computer Science (AI focus)", "years": "Oct 2024 - present",
     "note": "Focus: machine learning, advanced software architectures, computer vision."},
]

# ---------------------------------------------------------------------------
# 8. When I'm not working: dance, read, gym, run, journal
# ---------------------------------------------------------------------------
HOBBIES = [
    {"title": "Dance", "text": "I've tried many styles.",
     "tags": ["Locking", "Hip-hop", "Jazz", "K-pop"]},
    {"title": "Reading", "text": "TODO: one line, e.g. what you are reading now.", "tags": []},
    {"title": "Gym", "text": "TODO: one line about your training.", "tags": []},
    {"title": "Running", "text": "TODO: one line, e.g. your favourite route.", "tags": []},
    {"title": "Journalling", "text": "TODO: one line about why you journal.", "tags": []},
]
